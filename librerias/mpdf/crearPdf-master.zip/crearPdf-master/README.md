# crearPdf

DESCRIPCIÓN

El código muestra un formulario para realizar una consulta a nuestra Base de Datos MySQL. 
Cuando pulsamos el botón “Generar PDF” nos mostrará en pantalla el archivo PDF con la consulta de los registros a la 
Base de Datos para poder imprimirlo o guardarlo en nuestro disco duro.
Este código es totalmente adaptable a bases de datos MySQL.

REQUERIMIENTOS

Necesitaremos descargar la librería MPDF y guardarla en la carpeta MPDF:
http://www.mpdf1.com/mpdf/
En el archivo mysql-login.php que se encuentra en la carpeta PHP podremos introducir nuestras credenciales para 
conectarnos a la Base de Datos.
El código ya viene con el link hacia el CDN de BootStrap para los estilos CSS del formulario y la tabla.


Autor: Javier Jiménez García 
Blog: http://javierjimenez.mondaenlaweb.com
