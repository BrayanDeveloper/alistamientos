<?php
$name='Garuda-Bold';
$type='TTF';
$desc=array (
  'CapHeight' => 700,
  'XHeight' => 521,
  'FontBBox' => '[-750 -591 1099 1337]',
  'Flags' => 262148,
  'Ascent' => 1284,
  'Descent' => -591,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 165,
  'MissingWidth' => 766,
);
$unitsPerEm=1000;
$up=-37;
$ut=20;
$strp=258;
$strs=49;
$ttffile='/Applications/MAMP/htdocs/jpos2014/mpdf60/ttfonts/Garuda-Bold.ttf';
$TTCfontID='0';
$originalsize=57796;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='garudaB';
$panose=' 0 0 2 b 7 4 2 2 2 2 2 4';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 872, -128, 0
// usWinAscent/usWinDescent = 1284, -591
// hhea Ascent/Descent/LineGap = 1284, -591, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'thai' => 'DFLT KUY  PAL  THA  ',
);
$GSUBFeatures=array (
  'thai' => 
  array (
    'DFLT' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
    'KUY ' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
    'PAL ' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
      ' RQD' => 
      array (
        0 => 2,
      ),
    ),
    'THA ' => 
    array (
      'ccmp' => 
      array (
        0 => 0,
        1 => 1,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 2,
    'Subtables' => 
    array (
      0 => 56016,
      1 => 56424,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56612,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 5,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56648,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56676,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56694,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 2,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56714,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56770,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56782,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56798,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56816,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56834,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56852,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56870,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56888,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56906,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56924,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56942,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56960,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56978,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 56996,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57014,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57032,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57050,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57068,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57086,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57104,
    ),
    'MarkFilteringSet' => '',
  ),
  26 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57122,
    ),
    'MarkFilteringSet' => '',
  ),
  27 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57140,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'thai' => 'DFLT KUY  PAL  THA  ',
);
$GPOSFeatures=array (
  'thai' => 
  array (
    'DFLT' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
    'KUY ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
    'PAL ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
    'THA ' => 
    array (
      'mark' => 
      array (
        0 => 0,
        1 => 1,
      ),
      'mkmk' => 
      array (
        0 => 2,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57270,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57350,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 57600,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>